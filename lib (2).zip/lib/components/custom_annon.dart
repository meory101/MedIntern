import 'package:flutter/material.dart';

class CustomAnnouncment extends StatefulWidget {
  const CustomAnnouncment({super.key});

  @override
  State<CustomAnnouncment> createState() => _CustomAnnouncmentState();
}

class _CustomAnnouncmentState extends State<CustomAnnouncment> {
  @override
  Widget build(BuildContext context) {
    return Container() ;
  }
}