import 'package:flutter/material.dart';

Color maincolor = Color.fromARGB(255, 23, 180, 164);
Color subcolor = Color.fromARGB(255, 50, 115, 106);
Color boxcolor = Color.fromARGB(255, 71, 195, 150);
Color light_box_color = Color.fromARGB(255, 71, 195, 150).withOpacity(0.6);
