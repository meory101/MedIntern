import 'package:flutter/material.dart';

Color maincolor =const Color.fromARGB(255, 23, 180, 164);
Color subcolor =const Color.fromARGB(255, 50, 115, 106);
Color boxcolor =const Color.fromARGB(255, 71, 195, 150);
Color light_box_color =const Color.fromARGB(255, 71, 195, 150).withOpacity(0.6);
